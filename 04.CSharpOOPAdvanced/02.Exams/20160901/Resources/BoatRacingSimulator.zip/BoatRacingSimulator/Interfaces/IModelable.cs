﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IModelable
    {
        string Model { get; }
    }
}
