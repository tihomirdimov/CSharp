﻿namespace BoatRacingSimulator.Enumerations
{
    public enum EngineType
    {
        Jet,
        Sterndrive
    }
}
