﻿namespace SimpleMVC.Interfaces
{
    public interface IRenderable
    {
        string Render();
    }
}
