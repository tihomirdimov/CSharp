﻿namespace SimpleMVC.App.MVC.Attributes.Security
{
    class LogoutAttribute : SecurityAttribute
    {
    }
}
