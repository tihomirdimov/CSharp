﻿using System;
class DeclareVariables
{
    static void Main()
    {
        ushort inta = 52130;
        sbyte intb = -115;
        long intc = -4825932;
        sbyte intd = 97;
        short inte = -10000;
        Console.WriteLine(inta);
        Console.WriteLine(intb);
        Console.WriteLine(intc);
        Console.WriteLine(intd);
        Console.WriteLine(inte);
    }
}
