﻿using System;
class FloatOrDouble
{
    static void Main()
    {
        double fpn1 = 34.567839023d;
        float fpn2 = 12.345f;
        double fpn3 = 8923.1234857d;
        float fpn4 = 3456.091f;
        Console.WriteLine(fpn1);
        Console.WriteLine(fpn2);
        Console.WriteLine(fpn3);
        Console.WriteLine(fpn4);
    }
}
