﻿using System;
class UnicodeCharacter
{
    static void Main(string[] args)
    {
        var Value = "\u002A";
        Console.WriteLine(Value);
    }
}