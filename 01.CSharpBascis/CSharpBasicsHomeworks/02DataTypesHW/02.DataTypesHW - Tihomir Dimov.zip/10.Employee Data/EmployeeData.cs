﻿using System;
class EmployeeData
{
    static void Main()
    {
    string firstName = "Tihomir";
    string lastName = "Dimov";
    byte age = 29;
    char gender = 'm';
    ulong personalId = 8605212255;
    ulong employeeId = 5513000188;
        Console.WriteLine("First name: " + firstName);
        Console.WriteLine("Last name: " + lastName);
        Console.WriteLine("Age: " + age);
        Console.WriteLine("Gender: " + gender);
        Console.WriteLine("Personal ID: " + personalId);
        Console.WriteLine("Unique Employee number: " + employeeId);
    }
}
